# Blueprints в VR: снимки из сцены play_check

Сняты на ПК без шлема скриптом `scripts/shot_blueprint_vr.gd` (тот же VR-риг, фейковые контроллеры, камера на уровне глаз). 1600×1200.

## 1. Граф целиком: как он выглядит в VR

![01_25d_view.png](01_25d_view.png)

**1.** GreenCube: весь граф с точки, откуда он читается слева направо. Красная карточка-событие On Ready, зелёные Set/Get, круглые карточки-операторы (+, ×, sin), белые провода выполнения (с петлёй через Delay), цветные провода данных (голубой — Vector3, мятный — float, сиреневый — ссылка на объект сцены).

![02_25d_view.png](02_25d_view.png)

**2.** RedCube: компактный граф «On Ready → Delay → Set Visible»: объект мигает с задержкой в 1 с, петля возвращает выполнение к началу.

![03_25d_view.png](03_25d_view.png)

**3.** BlueCube: математический граф (часы, sin, cos, умножение, Make Vector3) с функцией и вызовом Set Transparency — граф среднего размера.

![04_01_overview.png](04_01_overview.png)

**4.** Тот же граф глазами пользователя: человек стоит у стола, граф висит в пространстве вокруг объектов сцены.

![05_25_side.png](05_25_side.png)

**5.** Граф сбоку: карточки стоят в 3D-пространстве, у графа есть глубина, а не плоскость.

## 2. Карточки: блоки событий, действий и операторов

![06_02b_card_1_focus.png](06_02b_card_1_focus.png)

**6.** Карточка On Ready под лучом контроллера (в фокусе): над ней кнопки копирования, смены и корзины. Порт Source (сиреневый) ведёт к объекту сцены, белый провод — выполнение.

![07_02b_card_5_focus.png](07_02b_card_5_focus.png)

**7.** Set Visible: карточка-действие. Порт Target (сиреневый) принимает объект, Value — значение true.

![08_02b_card_3_focus.png](08_02b_card_3_focus.png)

**8.** Delay — песочные часы с подписью и значением «1 s» на фишке.

![09_22_engine_method_focus.png](09_22_engine_method_focus.png)

**9.** Метод движка Rotate X: заголовок с иконкой класса, вход Target с меткой link (ссылка на объект), число Angle.

![10_23_extra_1_focus.png](10_23_extra_1_focus.png)

**10.** Get Time — «чистая» маленькая карточка-иконка без выполнения.

![11_02_card_14.png](11_02_card_14.png)

**11.** Операторы как круглые карточки: sin, × — в BlueCube они сплетаются в математическое выражение.

![12_02_card_16.png](12_02_card_16.png)

**12.** Make Vector3 — сборка вектора из трёх чисел с проводами от операторов.

![13_24_ray_on_card.png](13_24_ray_on_card.png)

**13.** Луч из руки снизу справа на карточке: он остаётся над карточкой, её портами и фишками.

![14_19_operators.png](14_19_operators.png)

**14.** Операторы: сравнения (=, ≤), арифметика (+, ×), логика (AND, NOT); тип результата подстраивается под входы, значения лежат фишками-таблетками.

![15_20_variable_box.png](15_20_variable_box.png)

**15.** Переменная — ящик с начальным значением в виде шайбы, стоит прямо в графе.

![16_14_adapters.png](16_14_adapters.png)

**16.** Режим Targets=Adapter: цель карточки — отдельная деталь цвета Object с именем члена.

## 3. Откуда берутся блоки: меню, кольцо, подсказки

![17_05_petals.png](17_05_petals.png)

**17.** Веер событий выбранного объекта (ready, child_entered_tree, …): блок-событие добавляется одним касанием.

![18_17b_tiles_sources.png](18_17b_tiles_sources.png)

**18.** Меню блоков плитками: быстрые плитки сверху, вкладки источников (GreenCube, Library, Global, Native), классы, строка поиска.

![19_17b_tiles_tasks.png](19_17b_tiles_tasks.png)

**19.** То же, сгруппировано по задачам (Events, Variables, Flow, Math…).

![20_17c_ring.png](20_17c_ring.png)

**20.** Радиальное меню у плюса карточки: сектора разделов.

![21_17d_ring_flow.png](21_17d_ring_flow.png)

**21.** Сектор Flow раскрыт — блоки раздела веером.

![22_17e_suggestions.png](22_17e_suggestions.png)

**22.** Подсказка «что дальше»: после карточки сразу предлагаются самые вероятные следующие блоки.

![23_17f_copy_button.png](23_17f_copy_button.png)

**23.** Кнопка копирования блока над карточкой.

![24_41_keyboard_false_typed.png](24_41_keyboard_false_typed.png)

**24.** Виртуальная клавиатура для поиска блока: клик лучом по клавише, строка поиска фильтрует каталог.

## 4. Виджеты ввода значений

![25_12_vector_window.png](25_12_vector_window.png)

**25.** Окно Vector: стрелки по осям X/Y/Z, поля X/Y/Z, кнопки Zero, Normalize, Done; всё вокруг затемняется.

![26_12b_vector_pulled.png](26_12b_vector_pulled.png)

**26.** Вектор тянут за конец стрелки: значение и шаг («step 0.1») подписаны, белая стрелка — сумма осей.

![27_12d_vector_axis_keypad.png](27_12d_vector_axis_keypad.png)

**27.** Цифровая клавиатура одной оси: поддерживает π, e, √, скобки (3π, π/2).

![28_18_color_picker.png](28_18_color_picker.png)

**28.** Окно Color: 2D-пикер (RGB/HSV, hex, альфа).

![29_18_color_globe.png](29_18_color_globe.png)

**29.** То же в режиме «глобус цветов»: 3D-шар, яркость слайдером, R/G/B и hex.

![30_18b_color_globe_turned.png](30_18b_color_globe_turned.png)

**30.** Глобус цветов после поворота: выбранный цвет (R 51, G 153, B 230, #3399e6) показан образцом внизу.

![31_18c_pipette.png](31_18c_pipette.png)

**31.** Пипетка в руке вместо контроллера: берёт цвет с объектов сцены, карточек, фишек.

![32_30_pins_0_name.png](32_30_pins_0_name.png)

**32.** Switch on Int: значение выхода правится числовой линией (подсказка «hold trigger: number line»), × убирает случай, + добавляет.

![33_30_pins_3_name.png](33_30_pins_3_name.png)

**33.** Make Transform3D: вход с вектором (0, 0, 0) в виде фишки с проводом.

![34_30_pins_2_name.png](34_30_pins_2_name.png)

**34.** Break Vector4: разбор структуры на компоненты; пин с глазом можно скрыть.

## 5. Коллекции: массивы и словари

![35_50_collections_grid_card_0.png](35_50_collections_grid_card_0.png)

**35.** For Each по массиву и Make Array: порты-сетки, пины в цвете элементов.

![36_50_collections_grid_card_3.png](36_50_collections_grid_card_3.png)

**36.** Pick Random и Get из словаря — блоки коллекций.

![37_51_collections_stack_rack_wire_card_1.png](37_51_collections_stack_rack_wire_card_1.png)

**37.** Коллекции в графе: Make Array, For Each, Get из словаря и переменная lamps (Dictionary[String, Color]) — типы различимы по цвету портов.

![38_52_make_pin_mark.png](38_52_make_pin_mark.png)

**38.** Луч на пине Make Array: появляется × для удаления элемента, + для добавления.

![39_53_box_item_mark.png](39_53_box_item_mark.png)

**39.** Переменная-массив scores Array[int]: шайбы элементов, правка одной шайбы.

![40_52_collections_scene_array.png](40_52_collections_scene_array.png)

**40.** Массив из сцены: выделенные кубы (RedCube, GreenCube, BlueCube) пронумерованы 0, 1, 2 и собираются в Array одним проводом.

![41_40_probe_variables.png](41_40_probe_variables.png)

**41.** Две переменные-коллекции рядом с Print и Make Array: doors Array[int] и lamps Dictionary[String, Color].

## 6. Функции графа

![42_40_fn_call_focus.png](42_40_fn_call_focus.png)

**42.** Вызов собственной функции open_door в графе: вход input_1, выход output_1, кнопка открыть тело.

![43_41_fn_plates.png](43_41_fn_plates.png)

**43.** Окно Functions: список функций графа плашками.

![44_42_fn_body.png](44_42_fn_body.png)

**44.** Тело функции: карточки Entry и Return, соединённые белым проводом выполнения.

![45_45_fn_entry_pure.png](45_45_fn_entry_pure.png)

**45.** Чистая функция (pure): переключатель в заголовке Entry.

![46_47_fn_open_after.png](46_47_fn_open_after.png)

**46.** Тело функции (Entry → Return) открыто над столом, под ним окно Functions со списком функций графа.
